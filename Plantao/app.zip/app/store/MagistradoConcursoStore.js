Ext.define('Plantao.store.MagistradoConcursoStore', {
    extend: 'Ext.data.Store',
    alias: 'store.magistradoconcursostore',
    model: 'Plantao.model.MagistradoConcursoModel',
    data: [
    ]
});