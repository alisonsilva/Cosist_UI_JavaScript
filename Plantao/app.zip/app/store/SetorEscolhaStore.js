Ext.define('Plantao.store.SetorEscolhaStore', {
    extend: 'Ext.data.Store',
    alias: 'store.setorescolhastore',
    model: 'Plantao.model.ReservaModel',
    data: [
    ]
});