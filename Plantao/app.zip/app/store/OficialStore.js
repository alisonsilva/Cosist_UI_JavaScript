Ext.define('Oficiais.store.OficialStore', {
    extend: 'Ext.data.Store',
    alias: 'store.oficialstore',
    model: 'Oficiais.model.OficialModel',
    data: [
    ]
});