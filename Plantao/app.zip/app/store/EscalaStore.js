Ext.define('Plantao.store.EscalaStore', {
    extend: 'Ext.data.Store',
    alias: 'store.escalastore',
    model: 'Plantao.model.EscalaModel',
    data: [
    ]
});