Ext.define('Plantao.store.MagistradoPermutaStore', {
    extend: 'Ext.data.Store',
    alias: 'store.magistradopermutastore',
    model: 'Plantao.model.MagistradoPermutaModel',
    data: [
    ]
});