Ext.define('Plantao.store.MagistradoStore', {
    extend: 'Ext.data.Store',
    alias: 'store.magistradostore',
    model: 'Plantao.model.MagistradoModel',
    data: [
    ]
});