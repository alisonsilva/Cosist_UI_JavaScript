Ext.define('Plantao.store.ConcursoStore', {
    extend: 'Ext.data.Store',
    alias: 'store.concursostore',
    model: 'Plantao.model.ConcursoModel',
    data: [
    ]
});