Ext.define('Plantao.store.SorteioStore', {
    extend: 'Ext.data.Store',
    alias: 'store.sorteiostore',
    model: 'Plantao.model.SorteioModel',
    data: [
    ]
});