Ext.define('Plantao.store.ReservaStore', {
    extend: 'Ext.data.Store',
    alias: 'store.reservastore',
    model: 'Plantao.model.ReservaModel',
    data: [
    ]
});