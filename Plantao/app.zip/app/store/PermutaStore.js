Ext.define('Plantao.store.PermutaStore', {
    extend: 'Ext.data.Store',
    alias: 'store.permutastore',
    model: 'Plantao.model.PermutaModel',
    data: [
    ]
});