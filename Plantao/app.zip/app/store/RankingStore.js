Ext.define('Plantao.store.RankingStore', {
    extend: 'Ext.data.Store',
    alias: 'store.rankingstore',
    model: 'Plantao.model.OficialModel',
    data: [
    ]
});