Ext.define('Plantao.store.PermutaEscalaStore', {
    extend: 'Ext.data.Store',
    alias: 'store.permutaescalastore',
    model: 'Plantao.model.PermutaEscalaModel',
    data: [
    ]
});