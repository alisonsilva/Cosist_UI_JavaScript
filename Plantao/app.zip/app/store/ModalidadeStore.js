Ext.define('Plantao.store.ModalidadeStore', {
    extend: 'Ext.data.Store',
    alias: 'store.modalidadestore',
    model: 'Plantao.model.ModalidadeModel',
    data: [
    ]
});