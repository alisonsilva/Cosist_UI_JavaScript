Ext.define('Plantao.store.StatusStore', {
    extend: 'Ext.data.Store',
    alias: 'store.statustore',
    model: 'Plantao.model.StatusModel',
    data: [
    ]
});