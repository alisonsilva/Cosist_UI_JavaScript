Ext.define('Plantao.view.criterio.CriterioController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.criteriocontroller',
    requires: [
        'Ext.window.Window'    
    ]   
   
});


