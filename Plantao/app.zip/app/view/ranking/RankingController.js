Ext.define('Plantao.view.ranking.RankingController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.rankingcontroller',
    requires: [
        'Ext.window.Window'    
    ]   
   
});


