Ext.define('Plantao.model.StatusModel', {
    extend: 'Ext.data.Model',
    idProperty: 'id',
    fields: [
        {name: 'nome', type: 'string'},
        {name: 'id', type: 'integer'}
    ]
});