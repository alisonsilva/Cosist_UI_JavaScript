Ext.define('Plantao.model.ResultadoSorteioModel', {
    extend: 'Ext.data.Model',
    idProperty: 'oficialJusticaId',
    fields: [
        {name: 'setorKey', type: 'integer'},
        {name: 'oficialJusticaId', type: 'string'},
        {name: 'sorteioId', type: 'integer'},
        {name: 'nomeOficial', type: 'string'},
        {name: 'matriculaOficial', type: 'string'},
        {name: 'nomeSetor', type: 'string'},
        {name: 'nomeCircunscricao', type: 'string'},
		{name: 'classificacao', type: 'integer'},
		{name: 'circunscricaoAtual', type: 'string'},
		{name: 'setorAtual', type: 'string'}
    ]
});