Ext.define('Plantao.model.OficialModel', {
    extend: 'Ext.data.Model',
    idProperty: 'matricula',
    fields: [
        {name: 'matricula', type: 'string'},
        {name: 'nome', type: 'string'},
        {name: 'preferencia', type: 'integer'},
        {name: 'localizacao', type: 'string'},
        {name: 'ranking', type: 'integer'},
        {name: 'diasCargo', type: 'integer'}
    ]
});