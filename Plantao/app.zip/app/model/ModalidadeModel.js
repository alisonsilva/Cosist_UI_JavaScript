Ext.define('Plantao.model.ModalidadeModel', {
    extend: 'Ext.data.Model',
    idProperty: 'id',
    fields: [
        {name: 'modalidade', type: 'string'},
		{name: 'id', type: 'integer'}
    ]
});